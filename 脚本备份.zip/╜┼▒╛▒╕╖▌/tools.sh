docker run -d -p 80:8080 --name collector -v /logs -v /home/webapp/shell:/usr/src/app -w /usr/src/app tuhu/collect:v3 ./startup.sh collector098 && docker logs -f collector

docker run --name kiba -e ELASTICSEARCH_URL=http://172.25.0.2:9200 --net=elk -p 5601:5601 -d kibana

docker run --name logstash -d -v /home/webapp:/etc/logstash -p 3456:3456/udp --net elk logstash logstash -f /etc/logstash/logstash.conf

clt:
        image: clt
        volumes:
                - /home/clt_events:/logs
                - /home/clt/webapp:/usr/src/app
        working_dir: /usr/src/app
        ports:
                - "81:8080"
        command: ./startup.sh collector098
        restart: always

logstash:
        image: logstash
        volumes:
                - /home/clt/logstash:/etc/logstash
        ports:
                - "3456:3456/udp"
        command: logstash -f /etc/logstash/logstash.conf
        environment:
                - LS_HEAP_SIZE=2048m
        restart: always

kibana:
        image: kibana
        environment:
                ELASTICSEARCH_URL=http://netscaler.tuhu.cn:19200
        ports:
                - "86:5601"
        restart: always



pure:
        image: stilliard/pure-ftpd:hardened
        ports:
                - "21:21"
                - "30000-30009:30000-30009"
        volumes:
                - /home/clt_events:/home/ftpuser/bi
        restart: always
        environment:
                - PUBLICHOST=192.168.10.230


pure:
        image: gists/pure-ftpd
        container_name: pure
        ports:
        - "21:21"
        - "30000-30009:30000-30009"
        volumes:
        - /home/clt_events:/home/ftpuser/bi
        - /home/clt/pure/pureftpd:/etc/pureftpd
        restart: always      

memcached0:
        image: memcached
        container_name: memcached0
        restart: always    
memcached1:
        image: memcached
        container_name: memcached1
        restart: always    
mcrouter:
        image: jamescarr/mcrouter
        container_name: mcrouter
        ports:
            - "5000:5000"
        links:
            - "memcached0:memcached0"
            - "memcached1:memcached1"
        command:
            mcrouter --config-str='{"pools":{"A":{"servers":["memcached0:11211", "memcached1:11211"]}},"route":"PoolRoute|A"}' -p 5000
        restart: always   

docker run -d --name memcached0 memcached
docker run -d --name memcached1 memcached
docker run -d -p 5000:5000 --link=memcached0:memcached0 --link=memcached1:memcached1 jmck/mcrouter 
Now we can use mcrouter as a regular memcache server!

docker03
10.1.1.66
docker04
10.1.1.67


docker05
10.1.1.41
docker06
10.1.1.43



kibana 4.6.0

logstash 2.4.0

Ywxo%2sPwxhm2
git auth key
85cf67c71132a704e0430239a76281bbff51f4e2

docker exec -it pure pure-pw show bi

pure-pw useradd bob -u ftpuser -d /home/ftpuser/bob
pure-pw mkdb

$ docker exec -it compose_pure_1 bash

 pure-pw useradd kev -u ftpuser -d /home/ftpuser/kev -t 1024 -T 1024 -y 1 -m
 pure-pw list
 pure-pw show kev
 pure-pw passwd kev -m
 pure-pw userdel kev -m
 pure-ftpwho -n
 exit


echo "admin:`openssl passwd -apr1`" | tee -a /etc/nginx/htpasswd.users

admin:Tuhu!@#

admin:$apr1$wZEY7FtC$DbCn5eKYdIZb0XRZYxC2r/

 docker run -d --name auth -p 80:82 -v /home/clt/nginx/default/:/etc/nginx/conf.d -v /home/clt/nginx/usr_auth/:/etc/nginx/uauth nginx

/etc/nginx/conf.d

8070

server {
    listen       82;
    server_name  localhost;

    #charset koi8-r;
    #access_log  /var/log/nginx/log/host.access.log  main;

    auth_basic "Restricted Access";
    auth_basic_user_file /etc/nginx/htpasswd.users;

    location / {
            proxy_pass http://192.168.10.230:86;
            proxy_http_version 1.1;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection 'upgrade';
            proxy_set_header Host $host;
            proxy_cache_bypass $http_upgrade;
    }

    #error_page  404              /404.html;

    # redirect server error pages to the static page /50x.html
    #
    error_page   500 502 503 504  /50x.html;
    location = /50x.html {
        root   /usr/share/nginx/html;
    }

    # proxy the PHP scripts to Apache listening on 127.0.0.1:80
    #
    #location ~ \.php$ {
    #    proxy_pass   http://127.0.0.1;
    #}

    # pass the PHP scripts to FastCGI server listening on 127.0.0.1:9000
    #
    #location ~ \.php$ {
    #    root           html;
    #    fastcgi_pass   127.0.0.1:9000;
    #    fastcgi_index  index.php;
    #    fastcgi_param  SCRIPT_FILENAME  /scripts$fastcgi_script_name;
    #    include        fastcgi_params;
    #}

    # deny access to .htaccess files, if Apache's document root
    # concurs with nginx's one
    #
    #location ~ /\.ht {
    #    deny  all;
    #}
}

docker run --name mongoclient -d -p 3001:3000 mongoclient/mongoclient



# cat /proc/version 
Linux version 2.6.32-279.el6.x86_64 (mockbuild@c6b9.bsys.dev.centos.org) (gcc version 4.4.6 20120305 (Red Hat 4.4.6-4) (GCC) ) #1 SMP Fri Jun 22 12:19:21 UTC 2012
# uname -a
Linux LAMP1.1 2.6.32-279.el6.x86_64 #1 SMP Fri Jun 22 12:19:21 UTC 2012 x86_64 x86_64 x86_64 GNU/Linux
# uname -r
2.6.32-279.el6.x86_64
# cat /etc/issue
CentOS release 6.3 (Final)
Kernel \r on an \m
# cat /etc/redhat-release 
CentOS release 6.3 (Final)
# file /bin/ls
/bin/ls: ELF 64-bit LSB executable, x86-64, version 1 (SYSV), dynamically linked (uses shared libs), for GNU/Linux 2.6.18, stripped


docker run -p 8099:80 --name paper -v /home/webapp/paper:/usr/share/nginx/html:ro -d nginx


echo "export PUBLICHOST=192.168.10.230" > /etc/profile.d/pureftpd-host.sh && chmod 755 /etc/profile.d/pureftpd-host.sh

curl -XPOST 'http://localhost:9200/_shield/user/kibana-server' -d '{"roles" : [ "kibana4_server"]}}'

#get index _mapping
curl -XGET 'http://localhost:9200/collector-*/_mapping?pretty'

#delete index
curl -XDELETE 'http://localhost:9200/logstash-httplog-*/'

#put template
curl -XPUT 'http://localhost:9200/_template/collector' -d @template.json

#delete template
curl -XDELETE 'http://localhost:9200/_template/collector'



#put template
curl -XPUT 'http://netscaler.tuhu.cn:19200/_template/collector' -d @template.json

#delete template
curl -XDELETE 'http://netscaler.tuhu.cn:19200/_template/collector'

#get index _mapping
curl -XGET 'http://netscaler.tuhu.cn:19200/collector-*/_mapping?pretty'

#delete index
curl -XDELETE 'http://netscaler.tuhu.cn:19200/collector-*/'

#delete index _mapping
curl -XDELETE http://netscaler.tuhu.cn:19200/collector-2015.09.14/_mapping/get_info

curl -XPUT 'http://10.1.1.41:9200/collector-*/_settings' -d '{ 
    "index" : { 
        "refresh_interval" : "15s" 
    } 
}' 

curl -XPUT 'http://10.1.1.41:9200/logstash-*/_settings' -d '{ 
    "index" : { 
        "refresh_interval" : "15s" 
    } 
}' 

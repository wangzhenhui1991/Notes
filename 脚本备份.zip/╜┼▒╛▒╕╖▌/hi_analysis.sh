#Crontab -e 7ZIP JOBS
00 * * * * /bin/sh /home/clt/7compress/compress.sh hour >/dev/null  2>&1
01 00 * * * /bin/sh /home/clt/7compress/compress.sh day >/dev/null  2>&1

#7compress.sh
#!/bin/bash

TYPE="$1"

CURRENT_TIME=`date -d '-1 hours' +%Y_%m_%d`
TIME=`date -d '-1 hours' +%Y_%m_%d_%H`
FILENAME=info_${TIME}_collector.log
FILE7Z=info_${TIME}_collector.7z
SRCDIR=/data/clt_events/clt_$CURRENT_TIME
HOUR_DESDIR=/data/clt_events/clt_${CURRENT_TIME}/$FILE7Z

YESTERDAY_TIME=`date -d yesterday +%Y_%m_%d`
YESTERDAY_SRCDIR=/data/clt_events/clt_$YESTERDAY_TIME
YESTERDAY_FILE7Z=info_${YESTERDAY_TIME}_collector.7z
YESTERDAY_DESDIR=/data/clt_events/clt_${YESTERDAY_TIME}/$YESTERDAY_FILE7Z

echo "Job started at Day : $CURRENT_TIME ; Hour : $TIME ."

cd $SRCDIR
if [ $TYPE == "hour" ]
then
  echo "Compress $SRCDIR/$FILENAME: to $HOUR_DESDIR...By Type>$TYPE"
  cd $SRCDIR
  7za a $HOUR_DESDIR $FILENAME
else
  echo "Compress $YESTERDAY_SRCDIR: to $YESTERDAY_DESDIR...By Type>$TYPE"
  cd $YESTERDAY_SRCDIR
  7za a $YESTERDAY_DESDIR *.log
fi

echo "Done."

#Create custom collector image
$docker run -it mave:3.3.9 bash 
$apt-get update && apt-get install -y expect
$exit
$docker commit your_container_id collector:nov

#Collector Compose File
clt:
        image: collector:nov
        container_name: clt
        volumes:
                - /data/clt_events:/logs
                - /home/clt/webapp:/usr/src/app
        working_dir: /usr/src/app
        ports:
                - "81:8080"
        command: ./startup.sh collector098
        restart: always
logstash:
        image: logstash:2.4.0
        container_name: cltstash
        volumes:
                - /home/clt/logstash:/etc/logstash
        ports:
                - "3456:3456/udp"
        command: logstash -f /etc/logstash/logstash.conf
        environment:
                - LS_HEAP_SIZE=2048m
        restart: always
pure:
        image: stilliard/pure-ftpd:hardened
        container_name: cltpure
        ports:
        - "21:21"
        - "30000-30009:30000-30009"
        environment:
                - PUBLICHOST=10.1.1.52
        volumes:
        - /data/clt_events:/home/ftpuser/bi
        restart: always

#Modify timezone
echo "Asia/Shanghai" > /etc/timezone


#Add FTP Usr
$ docker exec -it pure bash

pure-pw mkdb
pure-pw useradd bi -u ftpuser -d /home/ftpuser/bi -m


tuhu!@#

#Logstash conf
input{
  udp {
    port => 3456
    codec => "json_lines"
    workers => 4
    buffer_size => 10485760
    queue_size => 200000
  }
}
output {
  elasticsearch {
    hosts => ["netscaler.ad.tuhu.cn:19200"]
    index => "%{log_from}-%{+YYYY.MM.dd}"
    document_type => "%{event_type}"
  }
}

#Collector startup.sh 
#!/bin/bash

password="$1"

sourcedest="/usr/src/app"
cd $sourcedest
rm -rf ./hi.tuhu.com
rm -rf ./src
rm -f ./pom.xml

echo "Updating Source..."
/usr/bin/expect <<- DONE
  set timeout -1

  spawn git init
  spawn git clone https://youwo56@github.com/tuhu/hi.tuhu.com.git

  # Look for passwod prompt
  expect "Password*:"
  # Send password aka $password
  send -- "$password\r"
  # send blank line (\r) to make sure we get back to gui
  send -- "\r"
  expect eof
DONE

echo "Moving Source..."

mv -f /usr/src/app/hi.tuhu.com/tuhu_collector/* /usr/src/app

echo "Server Starting..."

mvn install jetty:run


 7za a info_2016_11_08_12_collector.7z info_2016_11_08_12_collector.log